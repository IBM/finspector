Finspector is designed to help users explore the fairness and bias of foundation models using interactive visualizations.

Package Install
---------------

**Prerequisites**
- [node](http://nodejs.org/)

```bash
npm install --save finspector_js
```
