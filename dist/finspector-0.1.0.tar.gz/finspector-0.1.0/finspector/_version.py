# Module version
__version__ = '0.1.0a0'

NPM_PACKAGE_RANGE='^0.1.0'
